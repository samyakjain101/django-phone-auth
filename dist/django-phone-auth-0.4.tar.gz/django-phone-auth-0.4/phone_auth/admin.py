from django.contrib import admin
from .models import PhoneNumber


admin.site.register(PhoneNumber)
