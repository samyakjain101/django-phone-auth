from django.apps import AppConfig


class PhoneAuthConfig(AppConfig):
    name = 'phone_auth'
