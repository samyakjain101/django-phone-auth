# django-phone-auth
## Installation
```INSTALLED_APPS = [
    ...
    phone_auth,
]```